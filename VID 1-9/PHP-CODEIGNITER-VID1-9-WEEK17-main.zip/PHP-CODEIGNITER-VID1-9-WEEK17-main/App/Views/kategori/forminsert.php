<?= $this->extend('template/admin') ?>

<?= $this->section('content') ?>

<h1>Form Insert</h1>

<?= $this->endSection() ?>